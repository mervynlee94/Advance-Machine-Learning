## Materials for "How to Win a Data Science Competition: Learn from Top Kagglers" course

This repository contains programming assignments notebooks for the [course](https://www.coursera.org/learn/competitive-data-science/home/welcome) about competitive data science.
